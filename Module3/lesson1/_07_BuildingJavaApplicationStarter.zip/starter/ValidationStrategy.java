public interface ValidationStrategy {
	boolean validateUser(User user);
}
