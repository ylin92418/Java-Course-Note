package com.udacity.cart.model;

public enum UserType {
	REGULAR,
	PLATINUM
}
